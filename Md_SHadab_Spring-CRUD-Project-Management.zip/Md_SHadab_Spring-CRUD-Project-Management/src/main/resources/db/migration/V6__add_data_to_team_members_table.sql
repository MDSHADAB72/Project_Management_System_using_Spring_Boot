INSERT INTO bugtracker.team_members VALUES (1, 'John', 'Thompson', 'j.thompson@spring.com');
INSERT INTO bugtracker.team_members VALUES (2, 'Mary', 'Johnson', 'm.johnson@spring.com');
INSERT INTO bugtracker.team_members VALUES (3, 'Judy', 'Gordon', 'j.gordon@spring.com');
INSERT INTO bugtracker.team_members VALUES (4, 'Frank', 'Williams', 'f.williams@spring.com');