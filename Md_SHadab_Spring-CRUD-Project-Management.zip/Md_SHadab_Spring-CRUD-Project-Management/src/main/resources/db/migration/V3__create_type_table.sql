USE bugtracker;
CREATE TABLE type
(
    type_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(30) NOT NULL
);